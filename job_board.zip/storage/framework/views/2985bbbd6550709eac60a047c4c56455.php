<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h1 class="h3 mb-4">Jobs</h1>

    <a href="<?php echo e(route('admin.jobs.create')); ?>" class="btn btn-primary mb-3">Create Job</a>

    <table class="table table-striped align-middle">
        <thead>
            <tr>
                <th>#</th>
                <th>Title</th>
                <th>Company</th>
                <th>Location</th>
                <th>Status</th>
                <th>Posted</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($job->id); ?></td>
                    <td><?php echo e($job->title); ?></td>
                    <td><?php echo e($job->company); ?></td>
                    <td><?php echo e($job->location); ?></td>
                    <td><span class="badge bg-<?php echo e($job->status === 'active' ? 'success' : 'secondary'); ?>"><?php echo e(ucfirst($job->status)); ?></span></td>
                    <td><?php echo e($job->created_at->diffForHumans()); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.jobs.show', $job)); ?>" class="btn btn-sm btn-info">View</a>
                        <a href="<?php echo e(route('admin.jobs.edit', $job)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form action="<?php echo e(route('admin.jobs.destroy', $job)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this job?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center">No jobs found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($jobs->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.admin-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PHP8.2\htdocs\job_board\resources\views/admin/jobs/index.blade.php ENDPATH**/ ?>