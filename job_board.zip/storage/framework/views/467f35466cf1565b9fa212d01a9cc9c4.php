<?php
    $navLinks = [
        'Dashboard'    => ['route' => 'admin.dashboard',          'pattern' => 'admin.dashboard',         'icon' => 'fas fa-globe'],
        'Jobs'         => ['route' => 'admin.jobs.index',         'pattern' => 'admin.jobs.*',            'icon' => 'fas fa-briefcase'],
        'Users'        => ['route' => 'admin.users.index',        'pattern' => 'admin.users.*',           'icon' => 'fas fa-users'],
        'Applications' => ['route' => 'admin.applications.index', 'pattern' => 'admin.applications.*',    'icon' => 'fas fa-file-alt'],
    ];
?>

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container-fluid">
        
        <a class="navbar-brand fw-bold" href="<?php echo e(route('admin.dashboard')); ?>">
            <?php echo e(config('app.name', 'Laravel')); ?> Admin
        </a>

        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNavbar"
                aria-controls="adminNavbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        
        <div class="collapse navbar-collapse" id="adminNavbar">
            
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <?php $__currentLoopData = $navLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a class="nav-link d-flex align-items-center <?php echo e(request()->routeIs($data['pattern']) ? 'active fw-semibold' : ''); ?>"
                           href="<?php echo e(route($data['route'])); ?>">
                            <i class="<?php echo e($data['icon']); ?> me-2"></i> <?php echo e(__($label)); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            
            <ul class="navbar-nav ms-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="adminUserDropdown" role="button"
                       data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-user me-1"></i> <?php echo e(e(Auth::user()->name)); ?>

                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="adminUserDropdown">
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">
                                <i class="fas fa-user-cog me-2"></i> Profile
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="dropdown-item">
                                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                                </button>
                            </form>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\PHP8.2\htdocs\job_board\resources\views/admin/layouts/navigation.blade.php ENDPATH**/ ?>