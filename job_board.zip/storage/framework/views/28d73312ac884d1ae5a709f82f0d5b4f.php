<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row">
        <!-- Job Info -->
        <div class="col-lg-8 mb-4">
            <h1 class="mb-1"><?php echo e($job->title); ?></h1>
            <h5 class="text-muted mb-3"><?php echo e($job->company); ?></h5>
            <p>
                <span class="badge bg-primary me-2"><?php echo e(ucfirst($job->type)); ?></span>
                <span class="badge bg-secondary me-2"><?php echo e($job->category); ?></span>
                <i class="fas fa-map-marker-alt text-muted me-1"></i><?php echo e($job->location); ?>

            </p>
            <p class="h5 text-success">$<?php echo e(number_format($job->salary)); ?>/year</p>
            <hr>
            <h4>Description</h4>
            <p><?php echo nl2br(e($job->description)); ?></p>

            <?php if($job->requirements): ?>
                <h4 class="mt-4">Requirements</h4>
                <p><?php echo nl2br(e($job->requirements)); ?></p>
            <?php endif; ?>

            <?php if($job->benefits): ?>
                <h4 class="mt-4">Benefits</h4>
                <p><?php echo nl2br(e($job->benefits)); ?></p>
            <?php endif; ?>

            <!-- Application form for applicants -->
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->role === 'applicant'): ?>
                    <?php if($hasApplied): ?>
                        <div class="alert alert-success">You have already applied to this job.</div>
                    <?php else: ?>
                        <form action="<?php echo e(route('applications.store')); ?>" method="POST" enctype="multipart/form-data" class="mt-5">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="job_id" value="<?php echo e($job->id); ?>">
                            <div class="mb-3">
                                <label class="form-label">Cover Letter</label>
                                <textarea class="form-control" name="cover_letter" rows="4"></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Resume (PDF/DOC)</label>
                                <input type="file" class="form-control" name="resume" accept=".pdf,.doc,.docx" required>
                            </div>
                            <button class="btn btn-primary" type="submit">Apply Now</button>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4">
            <div class="card mb-4">
                <div class="card-body text-center">
                    <h5 class="card-title mb-3">Company Info</h5>
                    <p class="small text-muted mb-0">
                        <?php echo e($job->user->bio ?? 'No information provided.'); ?>

                    </p>
                    <?php if($job->user && $job->user->website): ?>
                        <a href="<?php echo e($job->user->website); ?>" target="_blank" class="d-block mt-2">Website</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PHP8.2\htdocs\job_board\resources\views/jobs/show.blade.php ENDPATH**/ ?>