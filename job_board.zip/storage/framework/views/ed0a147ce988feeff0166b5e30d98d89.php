<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row mb-4 align-items-center">
        <div class="col-md-8">
            <h1 class="h3 mb-0">Applicant Dashboard</h1>
            <p class="text-muted">Welcome back, <?php echo e(auth()->user()->name); ?>!</p>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-6 col-lg-3 mb-4">
            <div class="card bg-primary text-white h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-uppercase mb-1">Applications</h6>
                            <h2 class="mb-0"><?php echo e($applicationCount); ?></h2>
                        </div>
                        <i class="fas fa-file-alt fa-3x opacity-50"></i>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-0 pt-0">
                    <a href="<?php echo e(route('applications.index')); ?>" class="text-white">
                        View all applications <i class="fas fa-arrow-right ms-1"></i>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 col-lg-3 mb-4">
            <div class="card bg-success text-white h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-uppercase mb-1">Saved Jobs</h6>
                            <h2 class="mb-0"><?php echo e($savedJobsCount); ?></h2>
                        </div>
                        <i class="fas fa-bookmark fa-3x opacity-50"></i>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-0 pt-0">
                    <a href="#" class="text-white">
                        View saved jobs <i class="fas fa-arrow-right ms-1"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Applications -->
    <div class="card mb-4">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Recent Applications</h5>
            <a href="<?php echo e(route('applications.index')); ?>" class="btn btn-sm btn-outline-primary">View All</a>
        </div>
        <div class="card-body p-0">
            <?php if($applications->isEmpty()): ?>
                <div class="text-center p-4">
                    <p class="text-muted mb-4">You haven't applied to any jobs yet.</p>
                    <a href="<?php echo e(route('jobs.index')); ?>" class="btn btn-primary">Browse Jobs</a>
                </div>
            <?php else: ?>
                <div class="list-group list-group-flush">
                    <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list-group-item">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1">
                                        <a href="<?php echo e(route('jobs.show', $application->job)); ?>"><?php echo e($application->job->title); ?></a>
                                    </h6>
                                    <p class="mb-1 text-muted">
                                        <?php echo e($application->job->company_name); ?> • <?php echo e($application->job->location); ?>

                                    </p>
                                    <small class="text-muted">
                                        Applied on <?php echo e($application->created_at->format('M d, Y')); ?>

                                        <span class="mx-2">•</span>
                                        Status: 
                                        <span class="badge bg-<?php echo e($application->status === 'submitted' ? 'primary' : ($application->status === 'under_review' ? 'info' : ($application->status === 'accepted' ? 'success' : 'secondary'))); ?>">
                                            <?php echo e(ucfirst(str_replace('_', ' ', $application->status))); ?>

                                        </span>
                                    </small>
                                </div>
                                <a href="<?php echo e(route('jobs.show', $application->job)); ?>" class="btn btn-sm btn-outline-primary">View Job</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Recommended Jobs -->
    <div class="card">
        <div class="card-header bg-white">
            <h5 class="mb-0">Recommended Jobs</h5>
        </div>
        <div class="card-body">
            <?php if($recommendedJobs->isEmpty()): ?>
                <p class="text-muted mb-0">No recommended jobs at the moment. Check back later!</p>
            <?php else: ?>
                <div class="row g-4">
                    <?php $__currentLoopData = $recommendedJobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="card h-100">
                                <div class="card-body">
                                    <h6 class="card-title">
                                        <a href="<?php echo e(route('jobs.show', $job)); ?>" class="text-decoration-none">
                                            <?php echo e($job->title); ?>

                                        </a>
                                    </h6>
                                    <p class="card-text text-muted small mb-2">
                                        <?php echo e($job->company_name); ?> • <?php echo e($job->location); ?>

                                    </p>
                                    <div class="mb-3">
                                        <span class="badge bg-primary"><?php echo e($job->type); ?></span>
                                        <?php if($job->category): ?>
                                            <span class="badge bg-secondary"><?php echo e($job->category); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <p class="card-text small text-muted">
                                        <?php echo e(Str::limit($job->description, 100)); ?>

                                    </p>
                                </div>
                                <div class="card-footer bg-transparent border-0 pt-0">
                                    <a href="<?php echo e(route('jobs.show', $job)); ?>" class="btn btn-sm btn-outline-primary w-100">
                                        View Details
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PHP8.2\htdocs\job_board\resources\views/applicant/dashboard.blade.php ENDPATH**/ ?>