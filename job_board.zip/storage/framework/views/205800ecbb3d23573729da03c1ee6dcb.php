<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="h3 mb-0">Job #<?php echo e($job->id); ?></h1>
        <div>
            <a href="<?php echo e(route('admin.jobs.edit', $job)); ?>" class="btn btn-sm btn-warning me-2">Edit</a>
            <a href="<?php echo e(route('admin.jobs.index')); ?>" class="btn btn-sm btn-secondary">Back</a>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <h4 class="card-title"><?php echo e($job->title); ?></h4>
            <p class="text-muted mb-2"><?php echo e($job->company); ?> &middot; <?php echo e($job->location); ?></p>
            <span class="badge bg-<?php echo e($job->status === 'active' ? 'success' : 'secondary'); ?>"><?php echo e(ucfirst($job->status)); ?></span>
            <hr>
            <p><?php echo nl2br(e($job->description)); ?></p>
            <ul class="list-unstyled mb-0">
                <li><strong>Category:</strong> <?php echo e($job->category); ?></li>
                <li><strong>Salary:</strong> <?php echo e(number_format($job->salary,2)); ?></li>
                <li><strong>Type:</strong> <?php echo e(ucfirst($job->type)); ?></li>
                <li><strong>Posted:</strong> <?php echo e($job->created_at->toDayDateTimeString()); ?></li>
                <li><strong>Closing Date:</strong> <?php echo e($job->closing_date ? $job->closing_date->toFormattedDateString() : 'N/A'); ?></li>
            </ul>
        </div>
    </div>

    <h4>Applications (<?php echo e($job->applications->count()); ?>)</h4>
    <div class="table-responsive">
        <table class="table table-bordered align-middle">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Applicant</th>
                    <th>Cover Letter</th>
                    <th>Status</th>
                    <th>Applied</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $job->applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($application->id); ?></td>
                        <td><?php echo e($application->user->name); ?><br><small class="text-muted"><?php echo e($application->user->email); ?></small></td>
                        <td><?php echo e(Str::limit($application->cover_letter, 50)); ?></td>
                        <td><span class="badge bg-<?php echo e($application->getStatusBadgeColor()); ?>"><?php echo e(ucfirst($application->status)); ?></span></td>
                        <td><?php echo e($application->created_at->diffForHumans()); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.applications.show', $application)); ?>" class="btn btn-sm btn-info">View</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="text-center">No applications yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.admin-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PHP8.2\htdocs\job_board\resources\views/admin/jobs/show.blade.php ENDPATH**/ ?>