<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h1 class="h4 mb-4">Application #<?php echo e($application->id); ?></h1>

    <div class="card mb-4">
        <div class="card-header fw-semibold">Applicant Details</div>
        <div class="card-body">
            <p><strong>Name:</strong> <?php echo e($application->user->name); ?></p>
            <p><strong>Email:</strong> <?php echo e($application->user->email); ?></p>
            <p><strong>Phone:</strong> <?php echo e($application->user->phone ?? 'N/A'); ?></p>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header fw-semibold">Job Details</div>
        <div class="card-body">
            <p><strong>Title:</strong> <?php echo e($application->job->title); ?></p>
            <p><strong>Company:</strong> <?php echo e($application->job->company); ?></p>
            <p><strong>Location:</strong> <?php echo e($application->job->location); ?></p>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header fw-semibold d-flex justify-content-between align-items-center">
            <span>Application</span>
            <span class="badge bg-<?php echo e($application->getStatusBadgeColor()); ?>"><?php echo e(ucfirst($application->status)); ?></span>
        </div>
        <div class="card-body">
            <p><strong>Cover Letter:</strong></p>
            <p><?php echo e($application->cover_letter); ?></p>

            <p><strong>Resume:</strong> <a href="<?php echo e(Storage::url($application->resume_path)); ?>" target="_blank">Download</a></p>
        </div>
    </div>

    <form action="<?php echo e(route('admin.applications.updateStatus', $application)); ?>" method="POST" class="d-inline">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="input-group mb-3" style="max-width: 300px;">
            <select name="status" class="form-select" required>
                <option value="pending" <?php if($application->status==='pending'): echo 'selected'; endif; ?>>Pending</option>
                <option value="reviewing" <?php if($application->status==='reviewing'): echo 'selected'; endif; ?>>Reviewing</option>
                <option value="accepted" <?php if($application->status==='accepted'): echo 'selected'; endif; ?>>Accepted</option>
                <option value="rejected" <?php if($application->status==='rejected'): echo 'selected'; endif; ?>>Rejected</option>
            </select>
            <button class="btn btn-primary">Update Status</button>
        </div>
    </form>

    <a href="<?php echo e(route('admin.applications.index')); ?>" class="btn btn-secondary mt-2">Back to list</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.admin-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PHP8.2\htdocs\job_board\resources\views/admin/applications/show.blade.php ENDPATH**/ ?>