<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h1 class="h3 mb-4">Applications</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-striped align-middle">
        <thead>
            <tr>
                <th>#</th>
                <th>Job</th>
                <th>Applicant</th>
                <th>Status</th>
                <th>Applied At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($application->id); ?></td>
                    <td><?php echo e($application->job->title); ?></td>
                    <td><?php echo e($application->user->name); ?></td>
                    <td>
                        <span class="badge bg-<?php echo e($application->getStatusBadgeColor()); ?>">
                            <?php echo e(ucfirst($application->status)); ?>

                        </span>
                    </td>
                    <td><?php echo e($application->created_at->diffForHumans()); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.applications.show', $application)); ?>" class="btn btn-sm btn-primary">View</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center">No applications found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($applications->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.admin-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PHP8.2\htdocs\job_board\resources\views/admin/applications/index.blade.php ENDPATH**/ ?>