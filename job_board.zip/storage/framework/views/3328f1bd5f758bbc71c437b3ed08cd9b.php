<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <h1 class="h4 mb-4">My Applications</h1>
            
            <?php if($applications->isEmpty()): ?>
                <div class="alert alert-info">
                    You haven't applied for any jobs yet. <a href="<?php echo e(route('jobs.index')); ?>">Browse available jobs</a>.
                </div>
            <?php else: ?>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Job Title</th>
                                        <th>Company</th>
                                        <th>Location</th>
                                        <th>Status</th>
                                        <th>Applied At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo e(route('jobs.show', $application->job)); ?>">
                                                    <?php echo e($application->job->title); ?>

                                                </a>
                                            </td>
                                            <td><?php echo e($application->job->company_name); ?></td>
                                            <td><?php echo e($application->job->location); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo e($application->getStatusBadgeColor()); ?>">
                                                    <?php echo e($application->status); ?>

                                                </span>
                                            </td>
                                            <td><?php echo e($application->created_at->format('M d, Y')); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('jobs.show', $application->job)); ?>" 
                                                   class="btn btn-sm btn-primary">
                                                    View Job
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <?php echo e($applications->links()); ?>

                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PHP8.2\htdocs\job_board\resources\views/applications/index.blade.php ENDPATH**/ ?>